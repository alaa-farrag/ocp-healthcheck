#!/usr/bin/perl

##########################################################################
# Gather Openshift Cluster Information                                   #
# Alaa Farrag (alaa.farrag@sa.ibm.com)                                   #
# 18/07/2021                                                             #
##########################################################################

use FindBin qw($Bin);

# Variables initializing
$sshkey="~/.ssh/id_rsa";
$sep1="-------------------------------------------------------------------------------------------------------------\n";
$sep2="#############################################################################################################\n";
$scriptDir=$Bin;
$curDate=`date +%Y_%m_%d_%H_%M_%S`;
chomp($curDate);
$outputDir=$scriptDir."/output-".$curDate."-".$$;
#$cfgFile=$scriptDir."/ocp-collector.conf";
$nodesCmdFile=$scriptDir."/nodes-cmd.cfg";
$clusterCmdFile=$scriptDir."/cluster-cmd.cfg";
$logsCmdFile=$scriptDir."/logs-cmd.cfg";

### Main Start ###

# Parsing command line arguments
foreach $cmdArg (@ARGV){
    if($cmdArg eq "--prereqs") # Prereq checking only
    {
        prereqsCheck();
        print("[INFO]: All prerequisites are met\n");
        exit 0;
    }
    else{
        print("[Error]: Unknown argument $cmdArg, exiting...\n");
        exit 1;
    }
}

# Get OCP Nodes basic information
getNodes();

# Parse nodes validation list
parseNodesCmd();

# Parse cluster validation list
parseClusterCmd();

# Parse cluster validation list
parseLogsCmd();

# Execute cluster Actions
runClusterActions();

# Create output dir:
!system("mkdir -p $outputDir/logs") || die "[ERROR]: Can't create output directory $outputDir - $!\n";

# Print cluster reports
print("Generating Cluster Reports to $outputDir\n");
foreach my $id (keys %clusterReport){
    my $reportFile=$outputDir."/cluster-".$id.".txt";
    open(OUT,">$reportFile") || die "[ERROR]: Can not open output file $reportFile for write\n";
    print OUT ($clusterReport{$id}."\n".$sep1);
    close(OUT);
}

# Execute nodes Actions
runNodesActions();

# Print cluster reports
print("Generating Node Reports to $outputDir\n");
foreach my $id (keys %nodesReport){
    my $reportFile=$outputDir."/node-".$id.".txt";
    open(OUT,">$reportFile") || die "[ERROR]: Can not open output file $reportFile for write\n";
    print OUT ($nodesReport{$id}."\n".$sep1);
    close(OUT);
}


# Execute nodes Actions
runLogsActions();

# Print logs reports
print("Generating Logs Reports to $outputDir/logs\n");
foreach my $id (keys %logsReport){
    my $reportFile=$outputDir."/logs/".$id.".log";
    open(OUT,">$reportFile") || die "[ERROR]: Can not open output file $reportFile for write\n";
    print OUT ($logsReport{$id}."\n".$sep1);
    close(OUT);
}

### Main End ###

sub prereqsCheck{
    print("[INFO]: Running oc check\n");
    getNodes();
    print("[INFO]: Running ssh check\n");
    foreach $node (keys %node2ip){
        print("Trying ssh to ".$node." - ".$node2ip{$node}."\n");
        my $stdOutS=execCmdWithValidationS('ssh -i '.$sshkey.' core@'.$node2ip{$node}." hostname");
    }
    print("[INFO]: checking jq is installed\n");
    my $stdOutS=execCmdWithValidationS("which jq1");
}

sub getNodes{
    my @stdOut=execCmdWithValidation("oc get node -o wide");
    shift(@stdOut);
    foreach my $line (@stdOut){
        my @t=split(/ +/,$line);
        $node2ip{$t[0]}=$t[6];
    }
}

sub parseNodesCmd{
    #loading nodes cmd list
    open(CFG, "< $nodesCmdFile")||die "[ERROR]: Can not open $nodesCmdFile\n";
    my @inList=<CFG>;
    chomp(@inList);
    close(CFG);

    foreach my $line (@inList){
        $line=~s/^\s+//; $line=~s/\s+$//; # removing leading and trailing spaces
        next if($line =~ /^#/ or $line eq "");
        push(@nodesActions,$line);
    }
}

sub parseClusterCmd{
    #loading nodes validation list
    open(CFG, "< $clusterCmdFile")||die "[ERROR]: Can not open $clusterCmdFile\n";
    my @inList=<CFG>;
    chomp(@inList);
    close(CFG);

    foreach my $line (@inList){
        $line=~s/^\s+//; $line=~s/\s+$//; # removing leading and trailing spaces
        next if($line =~ /^#/ or $line eq "");
        my @t=split(/,/,$line);
        my $cmdID=shift(@t);
        my $cmdString="";
        foreach my $cmdToken (@t){
            $cmdString.=$cmdToken,
        }
        $cmdString=~s/,$//;
        if(!$clusterActions{$cmdID}){
            $clusterActions{$cmdID}=$cmdString;
        }
        else{
            $clusterActions{$cmdID}.="@@".$cmdString;
        }
    }
}

sub parseLogsCmd{
    #loading logs list that need to be gathered
    open(CFG, "< $logsCmdFile")||die "[ERROR]: Can not open $logsCmdFile\n";
    my @inList=<CFG>;
    chomp(@inList);
    close(CFG);

    foreach my $line (@inList){
        $line=~s/^\s+//; $line=~s/\s+$//; # removing leading and trailing spaces
        next if($line =~ /^#/ or $line eq "");
        my @t=split(/,/,$line);
        $logsActions{$t[0]."--".$t[1]}="-n $t[0] -l $t[1]";
        $logId2Namespace{$t[0]."--".$t[1]}=$t[0];
    }
}

sub runClusterActions{
    foreach my $id (keys %clusterActions){
        my @cmdList=split(/@@/,$clusterActions{$id});
        foreach my $line (@cmdList){
            print("Executing $line\n");
            my $stdOutS=execCmdS($line);
            $clusterReport{$id}.=$sep1."Executing: ".$line."\n".$sep1;
            $clusterReport{$id}.=$stdOutS."\n".$sep1;
        } 
    }
}

sub runNodesActions{
    foreach $node (keys %node2ip){
        $nodesReport{$node}.="Node: ".$node." - ".$node2ip{$node}."\n";
        foreach my $line (@nodesActions){
            my $cmdString='ssh -i '.$sshkey.' core@'.$node2ip{$node}." ".$line;
            print("Executing $cmdString\n");
            my $stdOutS=execCmdS($cmdString);
            $nodesReport{$node}.=$sep1."Executing: ".$line."\n".$sep1;
            $nodesReport{$node}.=$stdOutS."\n".$sep1;
        }
    }
}

sub runLogsActions{
    foreach my $id (keys %logsActions){
        my $cmdString="oc get po -o name ".$logsActions{$id};
        my @stdOut=execCmd($cmdString);
        my $nsName=$logId2Namespace{$id};
        foreach my $line (@stdOut){
            my $logPodCmd="oc logs --all-containers $line -n $nsName";
            print("Executing $logPodCmd\n");
            my $stdOutS=execCmdS($logPodCmd);
            my $podName=$line;
            $podName=~s/\//-/;
            $logsReport{$nsName."-".$podName}.=$sep2."Executing: ".$logPodCmd."\n".$sep2;
            $logsReport{$nsName."-".$podName}.=$stdOutS."\n".$sep1;
        } 
    }
}

sub execCmd{
    my $inCmd=$_[0];
    my @outCmd="";
    (@outCmd=`$inCmd`);
    chomp(@outCmd);
    return @outCmd;
}
sub execCmdS{
    my $inCmd=$_[0];
    my $outCmd="";
    ($outCmd=`$inCmd`);
    chomp($outCmd);
    return $outCmd;
}

sub execCmdWithValidation{
    my $inCmd=$_[0];
    my @outCmd="";
    (@outCmd=`$inCmd`) || die "[ERROR]: Can't execute $inCmd, exiting...\n";
    chomp(@outCmd);
    return @outCmd;
}

sub execCmdWithValidationS{
    my $inCmd=$_[0];
    my $outCmd="";
    ($outCmd=`$inCmd`) || die "[ERROR]: Can't execute $inCmd, exiting...\n";
    chomp($outCmd);
    return $outCmd;
}

